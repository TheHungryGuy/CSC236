
public class Pets {

	//attributes
		private String petName;
		private String ownerName;
		private String species;
		private String breed;
		
		private double age;
		private double weight;
		
		
		
	//default constructor
		public Pets() {
			//don't do anything here
			//bec, it's just an empty object...
		}
		
		
		public Pets(String initPName, String initOName, 
				String initSpecies, String initBreed, double initAge, double initWeight){
			
				petName = initPName;
				ownerName = initOName;
				species = initSpecies;
				breed = initBreed;
				age = initAge;
				weight = initWeight;
			}
			
	//methods
		public String isSpecies() {
				return species;
			}
		
		public String toString() {
			String result;
			result = petName + ", " + ownerName + '\n' 
					+ species +", " + breed + ", " + '\n' 
					+ "Age: " + age +  '\n'
					+"Weight " + weight;
			return result;
		}

		
		
}
