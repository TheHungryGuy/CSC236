import java.io.File;
import java.util.Scanner;

public class PetsInfo {

	public static void main(String[] args) {
	
		Pets s1 = new Pets; 
		 String Dummy; 
		
		File file = new File ("C:\\Users\\TheRedBox\\Documents\\pets.dat");
	 
	 
	Scanner petfile = new Scanner(file){
		while (petfile.hasNext()) {
			petName = petfile.nextline;
			ownerName  = petfile.nextline;
			species  = petfile.nextline;
			breed = petfile.nextLine();
			age = petfile.nextDouble();
			weight =  petfile.nextDouble();
			dummy = petfile.nextLine();
				
		}
	}
		
	
		

	}

}
